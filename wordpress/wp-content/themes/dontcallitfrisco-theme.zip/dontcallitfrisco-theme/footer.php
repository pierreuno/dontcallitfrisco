		<div class="featured-background">
			<div class="footer container">
				<div class="row bottom-10">
					<div class="col-md-8 email-list-wrapper">
						<div class="email-list">
							<p class="email-list-title">JOIN OUR EMAIL LIST TO FIND OUT ABOUT NEW EPISODES</p>
							<input type="text" name="signup_email"/>
							<button class="j-o-i-n sign-up">JOIN</button>
							<p class="sign-up-loader">
								<img src="/wp-content/themes/dontcallitfrisco-theme/img/loader.gif"/>
							</p>
						</div>
					</div>
					<div class="col-md-4">
						<p class="text-right social-links">
							<a href="https://www.facebook.com/dontcallitfriscoseries" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
							<a href="https://www.instagram.com/dcfseries" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						</p>
						<p class="text-right">&copy; 2016 DON'T CALL IT FRISCO</p>
					</div>
				</div>
			</div>
		</div>

		<?php wp_footer(); ?>

	</body>
</html>
